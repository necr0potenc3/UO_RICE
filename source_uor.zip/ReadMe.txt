========================================================================
       KONSOLENANWENDUNG : UO_RICE
========================================================================


Diese UO_RICE-Anwendung hat der Anwendungs-Assistent f�r Sie erstellt.  

Diese Datei enth�lt eine Zusammenfassung dessen, was Sie in jeder der Dateien
finden, die Ihre UO_RICE-Anwendung bilden.

UO_RICE.dsp
    Diese Datei (Projektdatei) enth�lt Informationen auf Projektebene und wird zur
    Erstellung eines einzelnen Projekts oder Teilprojekts verwendet. Andere Benutzer k�nnen
    die Projektdatei (.dsp) gemeinsam nutzen, sollten aber die Makefiles lokal exportieren.

UO_RICE.cpp
    Dieses ist die Hauptquellcodedatei der Anwendung.


/////////////////////////////////////////////////////////////////////////////
Weitere Standarddateien:

StdAfx.h, StdAfx.cpp
    Diese Dateien werden zum Erstellen einer vorkompilierten Header-Datei (PCH) namens
    UO_RICE.pch und einer vorkompilierten Typdatei namens StdAfx.obj verwendet.


/////////////////////////////////////////////////////////////////////////////
Weitere Hinweise:

Der Anwendungs-Assistent verwendet "ZU ERLEDIGEN:", um Bereiche des Quellcodes zu
kennzeichnen, die Sie hinzuf�gen oder anpassen sollten.

/////////////////////////////////////////////////////////////////////////////
